// Mensagem do botão principal

function mostrarMensagem() {

    alert(

        "O agronegócio é essencial para a produção de alimentos, geração de empregos e desenvolvimento econômico do Brasil."

    );

}

// Rolagem suave do menu de navegação

document.querySelectorAll("nav a").forEach(link => {

    link.addEventListener("click", function (event) {

        event.preventDefault();

        const destino = document.querySelector(this.getAttribute("href"));

        destino.scrollIntoView({

            behavior: "smooth"

        });

    });

});

// Efeito de aparição dos cards ao rolar a página

const cards = document.querySelectorAll(".card");

function revelarCards() {

    cards.forEach(card => {

        const posicao = card.getBoundingClientRect().top;

        const alturaTela = window.innerHeight;

        if (posicao < alturaTela - 100) {

            card.classList.add("mostrar");

        }

    });

}

window.addEventListener("scroll", revelarCards);

window.addEventListener("load", revelarCards);

// Informações do agro exibidas automaticamente

const fatosAgro = [

    "O Brasil está entre os maiores exportadores de alimentos do mundo.",

    "O agronegócio gera milhões de empregos diretos e indiretos.",

    "A tecnologia tem aumentado a produtividade no campo.",

    "A produção agrícola é fundamental para a segurança alimentar."

];

let indiceAtual = 0;

function trocarFato() {

    const elemento = document.getElementById("fato-agro");

    if (elemento) {

        elemento.textContent = fatosAgro[indiceAtual];

        indiceAtual++;

        if (indiceAtual >= fatosAgro.length) {

            indiceAtual = 0;

        }

    }

}

setInterval(trocarFato, 5000);

// Exibe uma mensagem de boas-vindas ao entrar no site

window.addEventListener("load", () => {

    console.log("Bem-vindo ao Agro Forte!");

    trocarFato();

});